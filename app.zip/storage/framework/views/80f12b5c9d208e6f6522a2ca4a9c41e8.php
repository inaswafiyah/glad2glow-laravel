<header class="navbar">
    <div class="logo">
        <h1> <a href="<?php echo e(url ('/')); ?>"></a>
            <span class="letter">G</span><span class="letter">L</span><span class="letter letter-a">A</span><span class="letter letter-d">D</span><span class="letter">2</span><span class="letter">G</span><span class="letter">L</span><span class="letter">O</span><span class="letter">W</span><span class="dot">.</span>
        </h1>
        <p> <a href="<?php echo e(url ('/')); ?>"></a> BEAUTY EXPERT</p>
    </div>
    <nav class="nav-links">
        <ul>
            <li><a href="<?php echo e(url('/')); ?>" class="active">HOME</a></li>
            <li><a href="<?php echo e(url('/products')); ?>">FEATURED PRODUCT</a></li>
            <li><a href="<?php echo e(url('/sale')); ?>">SALE</a></li>
            <li><a href="#glowcare">GLOWCARE</a></li>
            <li>
                <a href="<?php echo e(url('/cart')); ?>" class="cart-icon">
                    <i class="fa-solid fa-cart-shopping"></i>
                    <span class="cart-count">0</span>
                </a>
            </li>
             <?php if(Route::has('login')): ?>
                <?php if(auth()->guard()->check()): ?>
                    <li>
                        <a href="<?php echo e(url('/dashboard')); ?>" class="dashboard-link">Dashboard</a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
            <li><a href="<?php echo e(route('login')); ?>" class="login-btn">LOGIN NOW</a></li>
           
        </ul>
    </nav>
    <div class="hamburger">
        <span></span>
        <span></span>
        <span></span>
    </div>
</header>
<?php /**PATH C:\Users\INAS WAFIAH\Pictures\coding\eduwork\glad2glow_laravel\resources\views/components/navbar.blade.php ENDPATH**/ ?>