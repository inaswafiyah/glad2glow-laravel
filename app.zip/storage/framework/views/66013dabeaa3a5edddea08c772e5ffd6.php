

<?php $__env->startSection('content'); ?>
    <style>
        h1.daftar-produk {
            text-align: center;
            color: #333;
            margin-top: 40px; /* turun ke bawah */
        }
        .product-grid {
            display: grid;
            grid-template-columns: repeat(1, 1fr); /* default HP */
            gap: 20px;
            margin-top: 50px;
            justify-items: center; /* posisi card ke tengah */
        }
        @media (min-width: 768px) {
            .product-grid {
                grid-template-columns: repeat(2, 1fr); /* tablet */
            }
        }
        @media (min-width: 1024px) {
            .product-grid {
                grid-template-columns: repeat(3, 1fr); /* laptop/PC */
            }
        }
        .product-card {
            background: #fff;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            text-align: center;
            width: 280px; /* biar semua card sama lebar */
        }
        .product-card img {
            max-width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
        }
        .product-card h3 {
            margin: 10px 0;
            color: #444;
        }
        .product-card p {
            font-size: 14px;
            color: #666;
        }
        .price {
            font-weight: bold;
            color: #e67e22;
            margin-top: 10px;
            display: block;
        }
        .pagination {
            margin-top: 30px;
            display: flex;
            justify-content: center;
        }
        .pagination svg {
            width: 20px;
        }
    </style>

    <h1 class="daftar-produk">Daftar Produk</h1>

    <div class="product-grid">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="product-card">
                <?php if($product->image): ?>
                    <img src="<?php echo e(filter_var($product->image, FILTER_VALIDATE_URL) ? $product->image : asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>">
                <?php else: ?>
                    <p>Tidak ada gambar</p>
                <?php endif; ?>
                <h3><?php echo e($product->name); ?></h3>
                <p><?php echo e($product->description); ?></p>
                <span class="price">Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?></span>
                <p><strong>Stok:</strong> <?php echo e($product->stock); ?></p>
                <p><strong>Kategori:</strong> <?php echo e($product->category->name ?? '-'); ?></p>
                <a href="<?php echo e(route ('product.click', $product->id)); ?>" target="_blank" class="btn btn-primary">Beli Sekarang</a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="pagination">
        <?php echo e($products->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\INAS WAFIAH\Pictures\coding\eduwork\glad2glow_laravel\resources\views/home.blade.php ENDPATH**/ ?>